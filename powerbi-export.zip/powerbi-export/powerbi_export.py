SCRIPT_INPUTS = []

import os
import sys
from pathlib import Path

from credential_loader import require_secret
from playwright.sync_api import sync_playwright

# ── Paths ────────────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).resolve().parent
# Dedicated session for the it-prod-bot identity used to view this report.
AUTH_FILE = SCRIPT_DIR / "auth_state_it-prod-bot.json"
SHOTS = SCRIPT_DIR / "shots"
DOWNLOADS = SCRIPT_DIR / "downloads"

REPORT_URL = (
    "https://app.powerbi.com/groups/32a55eb0-01f1-49ff-b7b2-5e50158518d1/"
    "reports/85abe34a-5b49-4aaf-aac2-39716f993f95/d2815c4b321c8901f88e"
    "?ctid=54a9d69c-39a9-4e4e-a6bb-d4e0084643a4&experience=power-bi"
)

EMAIL_KEY = "ONELOGIN_EMAIL_it-prod-bot"
PASSWORD_KEY = "ONELOGIN_PASSWORD_it-prod-bot"

HEADLESS = os.environ.get("PBI_HEADLESS", "1") != "0"
SLOWMO = int(os.environ.get("PBI_SLOWMO", "0"))      # ms delay between actions
LINGER_MS = int(os.environ.get("PBI_LINGER_MS", "0"))  # keep window open at end


def shot(page, name):
    p = SHOTS / name
    try:
        page.screenshot(path=str(p), full_page=False)
        print(f"  [shot] {p}")
    except Exception as e:
        print(f"  [shot failed] {name}: {e}")


def sign_in_flow(page, context):
    """Handle whatever sign-in surface Power BI throws up, in any order:
    the Power BI 'Enter your email' prompt, the Azure AD email (#i0116) and
    password (#i0118) steps, and the 'Stay signed in?' confirmation.
    Credentials are read lazily, only once a sign-in surface actually appears.
    """
    creds = {}

    def email():
        if "e" not in creds:
            creds["e"] = require_secret(EMAIL_KEY)
        return creds["e"]

    def password():
        if "p" not in creds:
            creds["p"] = require_secret(PASSWORD_KEY)
        return creds["p"]

    acted = False
    for _ in range(15):
        # Azure AD password
        if page.locator("#i0118").first.is_visible(timeout=1500):
            print("  step: AAD password")
            page.locator("#i0118").first.fill(password())
            page.locator("#idSIButton9, input[type=submit]").first.click()
            page.wait_for_timeout(2500)
            acted = True
            continue
        # Azure AD email
        if page.locator("#i0116").first.is_visible(timeout=1500):
            print("  step: AAD email")
            page.locator("#i0116").first.fill(email())
            page.locator("#idSIButton9, input[type=submit]").first.click()
            page.wait_for_timeout(2500)
            acted = True
            continue
        # Power BI "Enter your email" SSO prompt (no #i0116 present)
        pbi_email = page.locator("input[type='email'], input[placeholder*='email' i]").first
        if pbi_email.is_visible(timeout=1500):
            print("  step: Power BI email prompt")
            pbi_email.fill(email())
            page.locator("button:has-text('Submit'), button:has-text('Next'), input[type=submit]").first.click()
            page.wait_for_timeout(2500)
            acted = True
            continue
        # "Stay signed in?" confirmation
        if page.locator("#idSIButton9").first.is_visible(timeout=1500):
            print("  step: stay signed in")
            page.locator("#idSIButton9").first.click()
            page.wait_for_timeout(2500)
            acted = True
            continue
        break

    if acted:
        context.storage_state(path=str(AUTH_FILE))
    return acted


def needs_sign_in(page):
    url = page.url
    if "login.microsoftonline.com" in url or "/singleSignOn" in url or "login.live.com" in url:
        return True
    for sel in ("#i0116", "#i0118", "input[type='email']"):
        try:
            if page.locator(sel).first.is_visible(timeout=1000):
                return True
        except Exception:
            pass
    return False


def export_labor_variance(headless=None, slowmo=None, linger_ms=None):
    """Log into Power BI, export the target visual, and return the saved xlsx Path.

    Raises on failure (no visual found / download failed). Reuses the saved
    it-prod-bot session when present and signs in lazily otherwise.
    """
    headless = HEADLESS if headless is None else headless
    slowmo = SLOWMO if slowmo is None else slowmo
    linger_ms = LINGER_MS if linger_ms is None else linger_ms
    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=headless,
            channel="chrome",
            slow_mo=slowmo,
            args=["--ignore-certificate-errors", "--disable-http2", "--start-maximized"],
        )
        storage = str(AUTH_FILE) if AUTH_FILE.exists() else None
        context = browser.new_context(
            storage_state=storage,
            no_viewport=True,
            accept_downloads=True,
        )
        page = context.new_page()

        print(f"Navigating to report...")
        page.goto(REPORT_URL, wait_until="domcontentloaded", timeout=90000)
        page.wait_for_timeout(3000)

        if needs_sign_in(page):
            sign_in_flow(page, context)
            page.wait_for_timeout(3000)
            # After auth we may land on the PBI home rather than the report — go back.
            if "/reports/" not in page.url:
                page.goto(REPORT_URL, wait_until="domcontentloaded", timeout=90000)
                page.wait_for_timeout(3000)
                if needs_sign_in(page):
                    sign_in_flow(page, context)
                    page.wait_for_timeout(3000)

        # Let the report canvas render.
        print(f"Landed on: {page.url}")
        print("Waiting for report visuals to render...")
        try:
            page.locator("visual-container-modern, .visualContainer, [class*='visualContainer']").first.wait_for(timeout=60000)
        except Exception as e:
            print(f"  (visual container wait timed out: {e})")
        page.wait_for_timeout(8000)  # extra settle for data load
        shot(page, "01_report.png")

        # ── Pick the target visual: largest visible container that isn't the
        #    full-canvas wrapper (sorted by area, descending) ──
        vcs = page.locator("visual-container-modern, .visualContainer, [class*='visualContainer']")
        n = vcs.count()
        print(f"Visual containers found: {n}")
        candidates = []
        for i in range(n):
            el = vcs.nth(i)
            try:
                box = el.bounding_box()
            except Exception:
                box = None
            if not box:
                continue
            w, h = box["width"], box["height"]
            if w < 60 or h < 40:
                continue
            title = el.get_attribute("aria-label") or el.get_attribute("title") or ""
            cls = el.get_attribute("class") or ""
            # Skip overlay layers and the full-report wrapper — they sit behind
            # the real visuals and aren't exportable.
            if "Overlay" in cls or title.strip() == "Power BI Report":
                continue
            candidates.append({"i": i, "area": w * h, "box": box, "title": title})
        candidates.sort(key=lambda c: c["area"], reverse=True)
        print("Top visible visuals by area:")
        for c in candidates[:8]:
            b = c["box"]
            print(f"  vc[{c['i']}] area={int(c['area'])} pos=({int(b['x'])},{int(b['y'])}) "
                  f"size=({int(b['width'])}x{int(b['height'])}) title='{c['title'][:50]}'")

        if not candidates:
            shot(page, "05_no_visual.png")
            browser.close()
            raise RuntimeError("no visible visuals found on the report")

        chosen = candidates[0]
        target = vcs.nth(chosen["i"])
        box = chosen["box"]
        print(f"Target visual: vc[{chosen['i']}] size=({int(box['width'])}x{int(box['height'])})")

        # ── Step 1: hover the visual (top-right area) to reveal its header,
        #    then click "More options" ──
        print("Hovering target visual...")
        target.scroll_into_view_if_needed()
        # Move the mouse to the visual's top-right corner where the header lives.
        page.mouse.move(box["x"] + box["width"] - 20, box["y"] + 12)
        page.wait_for_timeout(1500)
        shot(page, "02_hover.png")

        more_btn = target.locator("button[aria-label*='More options' i]").first
        if not more_btn.is_visible(timeout=2000):
            # fall back to any visible 'More options' button on the page
            more_btn = page.locator("button[aria-label*='More options' i]:visible").first
        print("Clicking 'More options' (...)")
        more_btn.click()
        page.wait_for_timeout(1500)
        shot(page, "03_menu.png")

        # ── Step 2: click "Export data" in the menu ──
        export_data = page.locator(
            "[role='menuitem']:has-text('Export data'), button:has-text('Export data'), "
            "[role='menuitemcheckbox']:has-text('Export data')"
        ).first
        print("Clicking 'Export data'...")
        export_data.click()
        page.wait_for_timeout(2000)
        shot(page, "04_export_dialog.png")

        # ── Step 3: click "Export" in the dialog and capture the download ──
        export_confirm = page.locator(
            "button:has-text('Export'):not(:has-text('data'))"
        ).last
        print("Clicking 'Export' and waiting for download...")
        try:
            with page.expect_download(timeout=60000) as dl_info:
                export_confirm.click()
            download = dl_info.value
            out = DOWNLOADS / download.suggested_filename
            download.save_as(str(out))
            print(f"SUCCESS: downloaded export to {out}")
        except Exception as e:
            shot(page, "05_export_error.png")
            browser.close()
            raise RuntimeError(f"export/download failed: {e}")

        shot(page, "05_done.png")
        if linger_ms > 0:
            print(f"Keeping window open for {linger_ms} ms...")
            page.wait_for_timeout(linger_ms)
        browser.close()
        return out


def main():
    try:
        out = export_labor_variance()
        print(f"Export complete: {out}")
        return 0
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
