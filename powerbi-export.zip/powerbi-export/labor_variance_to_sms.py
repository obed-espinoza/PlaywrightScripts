SCRIPT_INPUTS = []

"""Labor Variance to SMS — Python replication of the Automation Anywhere bot.

Flow:
  1. Clean old data*.xlsx downloads.
  2. Load recipient list (Name, Phone Number, Email, Cc) from recipients.csv.
  3. Log into Power BI and export the Labor Variance visual -> data.xlsx
     (reuses powerbi_export.export_labor_variance).
  4. Read the weekly variance cells (A1:B5) from the export.
  5. Format a text message from the variance table.
  6. For each recipient: send a Twilio SMS (and, if enabled, an email with the
     spreadsheet attached).

Safety: this script SENDS FOR REAL by default — it exports the report and sends
SMS (and, if enabled, email) to every recipient in recipients.csv. Set
LV_DRY_RUN=1 to do a dry run that builds and prints the message + recipients and
sends NOTHING.

Env toggles:
  LV_DRY_RUN     "0" (default) = real sends; "1" = no sends (dry run)
  LV_SEND_EMAIL  "0" (default) = SMS only; "1" = also email
  LV_RECIPIENTS  path to recipients file (default: recipients.csv next to this script)
  PBI_HEADLESS   "1" (default) headless browser for the export; "0" headed
"""

import os
import re
import sys
import csv
import smtplib
import traceback
from datetime import datetime
from pathlib import Path
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

from openpyxl import load_workbook

from credential_loader import require_secret, get_secret
from powerbi_export import export_labor_variance

SCRIPT_DIR = Path(__file__).resolve().parent

# ── Config ───────────────────────────────────────────────────
DRY_RUN = os.environ.get("LV_DRY_RUN", "0") != "0"
SEND_EMAIL = os.environ.get("LV_SEND_EMAIL", "0") == "1"
RECIPIENTS_FILE = Path(os.environ.get("LV_RECIPIENTS", str(SCRIPT_DIR / "recipients.csv")))

USER_DOWNLOADS = Path(os.environ.get("USERPROFILE", r"C:\Users\it-prod-bot")) / "Downloads"
EXPORT_DOWNLOADS = SCRIPT_DIR / "downloads"

# Vault keys (mapped from the AA bot's variables)
TWILIO_SID_KEY = "TWILIO_ACCOUNT_SID"
TWILIO_TOKEN_KEY = "TWILIO_AUTH_TOKEN"
TWILIO_MSGSVC_KEY = "TWILIO_MESSAGING_SERVICE_SID"
SMTP_EMAIL_KEY = "it-prod-bot-EMAIL"
SMTP_PASSWORD_KEY = "it-prod-bot-PASSWORD"

ADMIN_EMAIL = "obed.espinoza@kbs-services.com"   # failure notifications
EMAIL_SUBJECT = "Labor Variance Report {date}"
EMAIL_BODY = (
    "Hi Team:\n\n"
    "Please find attached the latest Labor Variance Report exported from Power BI.\n"
    "The weekly variance summary is below.\n\n"
    "{summary}\n\n"
    "Should you require any information, please reply to this email.\n"
)
# Faithful replication of the original Automation Anywhere SMS: greeting +
# Power BI report link + the variance table rendered as comma-separated rows
# (header included), one row per line.
SMS_PREFIX = (
    "Hello, here's the Labor Variance Report\n\n"
    "https://app.powerbi.com/groups/32a55eb0-01f1-49ff-b7b2-5e50158518d1/"
    "reports/85abe34a-5b49-4aaf-aac2-39716f993f95/d2815c4b321c8901f88e"
    "?ctid=54a9d69c-39a9-4e4e-a6bb-d4e0084643a4&experience=power-bi\n\n"
)


# ── Helpers ──────────────────────────────────────────────────
def clean_downloads():
    """Delete stale data*.xlsx so we always read a fresh export."""
    removed = 0
    for folder in (USER_DOWNLOADS, EXPORT_DOWNLOADS):
        if not folder.exists():
            continue
        for f in folder.glob("data*.xlsx"):
            try:
                f.unlink()
                removed += 1
            except Exception as e:
                print(f"  could not delete {f}: {e}", file=sys.stderr)
    print(f"Cleaned {removed} old data*.xlsx file(s).")


def load_recipients(path):
    """Read recipients from CSV. Columns: Name, Phone Number, Email, Cc.
    Rows whose Name starts with '#' (comments) and rows with neither phone nor
    email are skipped."""
    if not path.exists():
        raise FileNotFoundError(
            f"Recipient list not found: {path}\n"
            f"  Fill in the template at {SCRIPT_DIR / 'recipients.csv'} "
            f"(columns: Name, Phone Number, Email, Cc)."
        )
    out = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            name = (row.get("Name") or "").strip()
            if name.startswith("#"):
                continue
            phone = (row.get("Phone Number") or "").strip()
            email = (row.get("Email") or "").strip()
            cc = (row.get("Cc") or "").strip()
            if not phone and not email:
                continue
            out.append({"name": name, "phone": phone, "email": email, "cc": cc})
    return out


def norm_phone(p):
    """Normalize a phone number to E.164 (+1 default for 10-digit US numbers)."""
    raw = str(p).strip()
    if not raw:
        return None
    digits = re.sub(r"\D", "", raw)
    if not digits:
        return None
    if raw.startswith("+"):
        return "+" + digits
    if len(digits) == 10:
        return "+1" + digits
    if len(digits) == 11 and digits.startswith("1"):
        return "+" + digits
    return "+" + digits


def _fmt_variance(val):
    """Format a variance cell to match the report's '-7.7%' display."""
    if val is None:
        return ""
    if isinstance(val, (int, float)):
        # Power BI exports percentages as fractions (e.g. -0.077).
        if abs(val) <= 1:
            return f"{val * 100:.1f}%"
        return f"{val:.1f}%"
    return str(val).strip()


def read_variance(xlsx_path):
    """Read cells A1:B5 -> list of (label, value) tuples (incl. header row)."""
    import warnings
    warnings.filterwarnings("ignore", message="Workbook contains no default style")
    wb = load_workbook(str(xlsx_path), data_only=True)
    ws = wb.active
    rows = []
    for r in ws.iter_rows(min_row=1, max_row=5, min_col=1, max_col=2, values_only=True):
        rows.append(r)
    return rows


def _fmt_week(week):
    """Format the week label (a date in the export) like the report: 5/31/2026."""
    if isinstance(week, datetime):
        return f"{week.month}/{week.day}/{week.year}"
    return str(week).strip()


def format_message(rows, stamp=None):
    """Build the variance summary text from the A1:B5 rows.

    Reproduces the AA bot: header row + comma-separated data rows, one per line.
    """
    lines = []
    if rows:
        hdr = rows[0]
        lines.append(f"{str(hdr[0]).strip()},{str(hdr[1]).strip()}")
    for week, var in [r for r in rows[1:] if r and r[0] is not None]:
        lines.append(f"{_fmt_week(week)},{_fmt_variance(var)}")
    return SMS_PREFIX + "\n".join(lines)


def send_sms(phone, message, sid, token, msg_svc):
    from twilio.rest import Client
    num = norm_phone(phone)
    if not num:
        print(f"  SMS skipped (no/invalid phone: {phone!r})")
        return
    Client(sid, token).messages.create(
        body=message, messaging_service_sid=msg_svc, to=num
    )
    print(f"  SMS sent -> {num}")


def send_email(to_addr, cc, subject, body, attachment, smtp_email, smtp_password):
    msg = MIMEMultipart()
    msg["Subject"] = subject
    msg["From"] = smtp_email
    msg["To"] = to_addr
    recipients = [to_addr]
    if cc:
        msg["Cc"] = cc
        recipients.append(cc)
    msg.attach(MIMEText(body, "plain", "utf-8"))
    if attachment and Path(attachment).exists():
        with open(attachment, "rb") as fh:
            part = MIMEApplication(fh.read(), Name=Path(attachment).name)
        part["Content-Disposition"] = f'attachment; filename="{Path(attachment).name}"'
        msg.attach(part)
    with smtplib.SMTP("smtp.office365.com", 587, timeout=30) as server:
        server.starttls()
        server.login(smtp_email, smtp_password)
        server.sendmail(smtp_email, recipients, msg.as_string())
    print(f"  Email sent -> {to_addr}" + (f" (cc {cc})" if cc else ""))


def notify_failure(err):
    """Best-effort failure notification email (mirrors the AA error metabot)."""
    try:
        smtp_email = get_secret(SMTP_EMAIL_KEY)
        smtp_password = get_secret(SMTP_PASSWORD_KEY)
        if not smtp_email or not smtp_password:
            print("  (failure email skipped — SMTP creds not set)", file=sys.stderr)
            return
        body = f"Labor Variance to SMS failed at {datetime.now():%Y-%m-%d %H:%M:%S}\n\n{err}"
        msg = MIMEText(body, "plain", "utf-8")
        msg["Subject"] = "FAILED: Labor Variance to SMS"
        msg["From"] = smtp_email
        msg["To"] = ADMIN_EMAIL
        with smtplib.SMTP("smtp.office365.com", 587, timeout=30) as server:
            server.starttls()
            server.login(smtp_email, smtp_password)
            server.sendmail(smtp_email, [ADMIN_EMAIL], msg.as_string())
        print(f"  Failure notice emailed to {ADMIN_EMAIL}")
    except Exception as e:
        print(f"  (failure email also failed: {e})", file=sys.stderr)


# ── Orchestration ────────────────────────────────────────────
def run():
    stamp = datetime.now().strftime("%m/%d/%Y")
    print("=" * 60)
    print(f"Labor Variance to SMS  |  DRY_RUN={DRY_RUN}  SEND_EMAIL={SEND_EMAIL}")
    print("=" * 60)

    clean_downloads()

    print(f"Loading recipients from {RECIPIENTS_FILE}...")
    recipients = load_recipients(RECIPIENTS_FILE)
    print(f"  {len(recipients)} recipient(s) loaded.")

    print("Exporting Labor Variance visual from Power BI...")
    xlsx = export_labor_variance()
    print(f"  Export saved: {xlsx}")

    rows = read_variance(xlsx)
    print("Raw cells A1:B5 (for verification):")
    for r in rows:
        print(f"    {r}")

    message = format_message(rows, stamp)
    print("\n--- Message to send ---")
    print(message)
    print("-----------------------\n")

    if not recipients:
        print("No usable recipients — nothing to send. "
              "Fill in recipients.csv (Name, Phone Number, Email, Cc).")
        return

    if DRY_RUN:
        print("DRY-RUN: would send to:")
        for r in recipients:
            tgt = norm_phone(r["phone"]) or "(no phone)"
            extra = f" + email {r['email']}" if (SEND_EMAIL and r["email"]) else ""
            print(f"  - {r['name'] or '(no name)'}  SMS {tgt}{extra}")
        print("\nNo messages sent (DRY_RUN). Set LV_DRY_RUN=0 to send for real.")
        return

    # ── Real send ──
    sid = require_secret(TWILIO_SID_KEY)
    token = require_secret(TWILIO_TOKEN_KEY)
    msg_svc = require_secret(TWILIO_MSGSVC_KEY)
    smtp_email = smtp_password = None
    if SEND_EMAIL:
        smtp_email = require_secret(SMTP_EMAIL_KEY)
        smtp_password = require_secret(SMTP_PASSWORD_KEY)
        email_subject = EMAIL_SUBJECT.format(date=stamp)
        email_body = EMAIL_BODY.format(summary=message)

    sent, failed = 0, 0
    for r in recipients:
        label = r["name"] or r["phone"] or r["email"]
        print(f"Sending to {label}...")
        try:
            if r["phone"]:
                send_sms(r["phone"], message, sid, token, msg_svc)
            if SEND_EMAIL and r["email"]:
                send_email(r["email"], r["cc"], email_subject, email_body,
                           xlsx, smtp_email, smtp_password)
            sent += 1
        except Exception as e:
            failed += 1
            print(f"  send failed for {label}: {e}", file=sys.stderr)

    print(f"\nDone. {sent} recipient(s) processed, {failed} failure(s).")


def main():
    try:
        run()
        return 0
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        traceback.print_exc()
        notify_failure(e)
        return 1


if __name__ == "__main__":
    sys.exit(main())
