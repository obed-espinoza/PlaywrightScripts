import os

try:
    from dotenv import dotenv_values
except ImportError:
    dotenv_values = None

_VAULT = os.environ.get(
    "CREDENTIAL_VAULT_PATH",
    r"C:\ProgramData\PlaywrightRunner\secrets\.env"
)
_CACHE = None


def _load():
    global _CACHE
    if dotenv_values is None:
        raise ImportError(
            "python-dotenv is not installed. "
            "Run: pip install python-dotenv"
        )
    if _CACHE is None and os.path.exists(_VAULT):
        _CACHE = dotenv_values(_VAULT)
    return _CACHE or {}


def get_secret(key, default=""):
    return _load().get(key, default)


def require_secret(key):
    val = _load().get(key)
    if not val:
        raise EnvironmentError(
            f"Required secret '{key}' not found in vault\n"
            f"  Vault: {_VAULT}\n"
            f"  Add it with: {key}=your_value_here in that file"
        )
    return val
